# Advanced AI Chatbot

A modern, full-stack AI chatbot application with a beautiful UI and intelligent conversation capabilities.

![Chatbot Preview](https://img.shields.io/badge/Version-1.0.0-blue)
![Python](https://img.shields.io/badge/Python-3.8+-green)
![Flask](https://img.shields.io/badge/Flask-3.0.0-red)

## Features

- **Modern UI/UX**: Beautiful dark-themed interface with smooth animations
- **AI-Powered**: Integration with OpenAI GPT models for intelligent responses
- **Conversation Memory**: Maintains context across messages within a session
- **Session Management**: Create new chats, view history, manage sessions
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Fallback Mode**: Works without OpenAI API key using built-in responses
- **Real-time Status**: Connection status indicator
- **Customizable Settings**: Theme, API endpoint, sound effects, auto-scroll

## Project Structure

```
advanced-chatbot/
├── backend/
│   ├── app.py              # Flask API server
│   ├── chatbot.py          # Chatbot logic & AI integration
│   ├── config.py           # Configuration settings
│   └── requirements.txt    # Python dependencies
├── frontend/
│   ├── index.html          # Main HTML file
│   ├── styles.css          # Modern CSS styling
│   └── script.js           # Frontend JavaScript
├── .env                    # Environment variables (create from .env.example)
└── README.md               # This file
```

## Quick Start

### 1. Setup Backend

```bash
# Navigate to backend directory
cd backend

# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy the example environment file
cp .env .env.local

# Edit .env.local with your settings
# Add your OpenAI API key (optional - bot works in fallback mode without it)
```

### 3. Run the Application

```bash
# Start the backend server
python backend/app.py

# The server will start on http://localhost:5000
```

### 4. Open Frontend

Simply open `frontend/index.html` in your web browser, or serve it using a local server:

```bash
# Using Python's built-in server
cd frontend
python -m http.server 3000

# Or using Node.js http-server
npx http-server -p 3000
```

Then navigate to `http://localhost:3000`

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check |
| `/api/chat` | POST | Send message & get response |
| `/api/chat/history/<session_id>` | GET | Get conversation history |
| `/api/chat/clear/<session_id>` | POST | Clear session history |
| `/api/chat/session/<session_id>` | DELETE | Delete session |
| `/api/admin/sessions` | GET | List all active sessions |
| `/api/admin/cleanup` | POST | Cleanup expired sessions |

### Example API Usage

```bash
# Send a message
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, how are you?"}'

# Health check
curl http://localhost:5000/api/health
```

## Configuration Options

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | - | Flask secret key |
| `DEBUG` | False | Enable debug mode |
| `PORT` | 5000 | Server port |
| `HOST` | 0.0.0.0 | Server host |
| `OPENAI_API_KEY` | - | OpenAI API key |
| `OPENAI_MODEL` | gpt-3.5-turbo | AI model to use |
| `OPENAI_TEMPERATURE` | 0.7 | Response creativity (0-1) |
| `OPENAI_MAX_TOKENS` | 150 | Max response length |
| `MAX_CONVERSATION_HISTORY` | 10 | Messages to remember |
| `SESSION_TIMEOUT` | 3600 | Session expiry (seconds) |

### Frontend Settings

Settings are saved in browser localStorage:
- **API Endpoint**: Backend server URL
- **Theme**: Dark/Light/Auto
- **Sound Effects**: Enable/disable notification sounds
- **Auto-scroll**: Automatically scroll to new messages

## Screenshots

The chatbot features:
- Clean, modern interface with gradient accents
- Smooth message animations
- Typing indicators
- Message timestamps
- Suggestion chips for quick queries
- Mobile-responsive sidebar

## Development

### Backend Development

```bash
# Run with auto-reload
FLASK_ENV=development python backend/app.py

# Run with debug mode
DEBUG=True python backend/app.py
```

### Frontend Development

The frontend is vanilla HTML/CSS/JS - no build step required! Just edit and refresh.

## Deployment

### Backend (Production)

```bash
# Using Gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 backend.app:app

# Or with a WSGI server
python -m gunicorn backend.app:app
```

### Frontend

Deploy the `frontend/` folder to any static hosting:
- GitHub Pages
- Netlify
- Vercel
- AWS S3
- Any web server

## Troubleshooting

### CORS Issues
If you see CORS errors, update `CORS_ORIGINS` in your `.env`:
```
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

### OpenAI API Errors
- Verify your API key is correct
- Check your OpenAI account has available credits
- The bot will fall back to basic responses if API fails

### Connection Issues
- Ensure the backend is running on the configured port
- Check firewall settings
- Verify the API endpoint in frontend settings

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

---

Built with Python, Flask, and modern web technologies.