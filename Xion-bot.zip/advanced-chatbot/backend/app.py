"""
Flask Backend API for Advanced Chatbot
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import time
from chatbot import chatbot
from config import Config

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = Config.SECRET_KEY

# Enable CORS
CORS(app, origins=Config.CORS_ORIGINS)

# Request timing middleware
@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    if hasattr(request, 'start_time'):
        elapsed = time.time() - request.start_time
        response.headers['X-Response-Time'] = f'{elapsed:.3f}s'
    return response


# Health check endpoint
@app.route('/api/health', methods=['GET'])
def health_check():
    """Check API health status"""
    return jsonify({
        'status': 'healthy',
        'timestamp': time.time(),
        'version': '1.0.0',
        'ai_enabled': chatbot.openai_client is not None
    })


# Chat endpoint
@app.route('/api/chat', methods=['POST'])
def chat():
    """Process a chat message and return AI response"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        message = data.get('message', '').strip()
        session_id = data.get('session_id')
        
        if not message:
            return jsonify({'error': 'Message is required'}), 400
        
        # Process the message
        result = chatbot.process_message(session_id, message)
        
        return jsonify({
            'success': True,
            'data': result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# Get session history endpoint
@app.route('/api/chat/history/<session_id>', methods=['GET'])
def get_history(session_id):
    """Get conversation history for a session"""
    try:
        history = chatbot.get_session_history(session_id)
        
        if history is None:
            return jsonify({
                'success': False,
                'error': 'Session not found or expired'
            }), 404
        
        return jsonify({
            'success': True,
            'data': {
                'session_id': session_id,
                'history': history
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# Clear session endpoint
@app.route('/api/chat/clear/<session_id>', methods=['POST'])
def clear_session(session_id):
    """Clear conversation history for a session"""
    try:
        success = chatbot.clear_session(session_id)
        
        if not success:
            return jsonify({
                'success': False,
                'error': 'Session not found'
            }), 404
        
        return jsonify({
            'success': True,
            'message': 'Session history cleared successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# Delete session endpoint
@app.route('/api/chat/session/<session_id>', methods=['DELETE'])
def delete_session(session_id):
    """Delete a session entirely"""
    try:
        success = chatbot.delete_session(session_id)
        
        if not success:
            return jsonify({
                'success': False,
                'error': 'Session not found'
            }), 404
        
        return jsonify({
            'success': True,
            'message': 'Session deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# Get all active sessions (admin endpoint)
@app.route('/api/admin/sessions', methods=['GET'])
def get_all_sessions():
    """Get all active sessions (for monitoring)"""
    try:
        sessions_info = []
        for session_id, session in chatbot.sessions.items():
            sessions_info.append({
                'session_id': session_id,
                'created_at': session.created_at.isoformat(),
                'last_activity': session.last_activity.isoformat(),
                'message_count': len(session.history),
                'is_expired': session.is_expired()
            })
        
        return jsonify({
            'success': True,
            'data': {
                'total_sessions': len(sessions_info),
                'sessions': sessions_info
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# Cleanup expired sessions endpoint
@app.route('/api/admin/cleanup', methods=['POST'])
def cleanup_sessions():
    """Manually trigger cleanup of expired sessions"""
    try:
        initial_count = len(chatbot.sessions)
        chatbot.cleanup_expired_sessions()
        final_count = len(chatbot.sessions)
        
        return jsonify({
            'success': True,
            'data': {
                'sessions_removed': initial_count - final_count,
                'remaining_sessions': final_count
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'success': False,
        'error': 'Endpoint not found'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500


if __name__ == '__main__':
    # Validate configuration
    Config.validate()
    
    print(f"""
    ╔══════════════════════════════════════════════════════════════╗
    ║                 Advanced Chatbot Server                      ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Server running at: http://{Config.HOST}:{Config.PORT}              ║
    ║  AI Integration: {'Enabled' if chatbot.openai_client else 'Disabled (Fallback Mode)'}                    ║
    ║  Debug Mode: {'Enabled' if Config.DEBUG else 'Disabled'}                          ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    # Run the Flask server
    app.run(
        host=Config.HOST,
        port=Config.PORT,
        debug=Config.DEBUG
    )