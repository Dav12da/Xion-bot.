"""
Advanced Chatbot Logic with Conversation Memory and Context Handling
"""
import time
import uuid
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import openai
from config import Config

class ConversationSession:
    """Manages a single conversation session with history and context"""
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.history: List[Dict[str, str]] = []
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
        self.context: Dict = {}
    
    def add_message(self, role: str, content: str):
        """Add a message to the conversation history"""
        self.history.append({
            'role': role,
            'content': content,
            'timestamp': datetime.now().isoformat()
        })
        self.last_activity = datetime.now()
        
        # Trim history if it exceeds max length
        if len(self.history) > Config.MAX_CONVERSATION_HISTORY * 2:
            self.history = self.history[-Config.MAX_CONVERSATION_HISTORY * 2:]
    
    def get_context_window(self) -> List[Dict[str, str]]:
        """Get the recent conversation context for the AI"""
        return [{'role': msg['role'], 'content': msg['content']} 
                for msg in self.history[-Config.MAX_CONVERSATION_HISTORY * 2:]]
    
    def is_expired(self) -> bool:
        """Check if the session has expired due to inactivity"""
        timeout = timedelta(seconds=Config.SESSION_TIMEOUT)
        return datetime.now() - self.last_activity > timeout
    
    def clear_history(self):
        """Clear conversation history"""
        self.history = []
        self.context = {}


class ChatbotEngine:
    """Core chatbot engine with AI integration"""
    
    def __init__(self):
        self.sessions: Dict[str, ConversationSession] = {}
        self.system_prompt = """You are an advanced AI assistant powered by state-of-the-art language models. 
You are helpful, creative, clever, and very friendly. You can:
- Answer questions on a wide range of topics
- Help with writing, coding, and analysis
- Engage in meaningful conversations
- Provide explanations and tutorials
- Assist with problem-solving

Always be concise but thorough in your responses. If you're unsure about something, be honest about it."""
        
        # Initialize OpenAI client if API key is available
        if Config.OPENAI_API_KEY:
            openai.api_key = Config.OPENAI_API_KEY
            self.openai_client = openai
        else:
            self.openai_client = None
    
    def create_session(self) -> str:
        """Create a new conversation session"""
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = ConversationSession(session_id)
        return session_id
    
    def get_session(self, session_id: str) -> Optional[ConversationSession]:
        """Get an existing session or return None"""
        session = self.sessions.get(session_id)
        if session and session.is_expired():
            del self.sessions[session_id]
            return None
        return session
    
    def cleanup_expired_sessions(self):
        """Remove expired sessions"""
        expired = [sid for sid, session in self.sessions.items() if session.is_expired()]
        for sid in expired:
            del self.sessions[sid]
    
    def generate_ai_response(self, message: str, context: List[Dict[str, str]]) -> str:
        """Generate AI response using OpenAI API or fallback"""
        if not self.openai_client:
            return self._fallback_response(message)
        
        try:
            messages = [{'role': 'system', 'content': self.system_prompt}]
            messages.extend(context)
            messages.append({'role': 'user', 'content': message})
            
            response = self.openai_client.chat.completions.create(
                model=Config.OPENAI_MODEL,
                messages=messages,
                temperature=Config.OPENAI_TEMPERATURE,
                max_tokens=Config.OPENAI_MAX_TOKENS
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            print(f"OpenAI API error: {e}")
            return self._fallback_response(message)
    
    def _fallback_response(self, message: str) -> str:
        """Generate fallback response when AI is unavailable"""
        message_lower = message.lower()
        
        # Simple pattern matching for common queries
        if any(word in message_lower for word in ['hello', 'hi', 'hey']):
            return "Hello! Welcome! I'm currently running in fallback mode. How can I assist you today?"
        
        if any(word in message_lower for word in ['help', 'assist', 'support']):
            return "I'm here to help! While I'm in fallback mode, I can still try to assist with basic queries. What do you need help with?"
        
        if any(word in message_lower for word in ['time', 'date', 'day']):
            now = datetime.now()
            return f"Current date and time: {now.strftime('%Y-%m-%d %H:%M:%S')}"
        
        if any(word in message_lower for word in ['weather', 'temperature']):
            return "I'm unable to check real-time weather data in fallback mode. Please check a weather service or enable the AI integration."
        
        if any(word in message_lower for word in ['name', 'who are you']):
            return "I'm an advanced AI chatbot assistant. I'm currently operating in fallback mode, which means my responses are limited. For full functionality, please configure the OpenAI API key."
        
        if any(word in message_lower for word in ['bye', 'goodbye', 'see you']):
            return "Goodbye! Have a great day! Feel free to come back anytime."
        
        return f"I received your message: '{message}'. I'm currently in fallback mode with limited capabilities. For more intelligent responses, please configure the OpenAI API key in the environment variables."
    
    def process_message(self, session_id: Optional[str], message: str) -> Dict:
        """Process a user message and return a response"""
        # Create new session if needed
        if not session_id or session_id not in self.sessions:
            session_id = self.create_session()
        
        session = self.get_session(session_id)
        if not session:
            session_id = self.create_session()
            session = self.get_session(session_id)
        
        # Add user message to history
        session.add_message('user', message)
        
        # Generate response
        context = session.get_context_window()
        response_text = self.generate_ai_response(message, context)
        
        # Add assistant response to history
        session.add_message('assistant', response_text)
        
        return {
            'session_id': session_id,
            'response': response_text,
            'timestamp': datetime.now().isoformat(),
            'history_length': len(session.history)
        }
    
    def get_session_history(self, session_id: str) -> Optional[List[Dict]]:
        """Get conversation history for a session"""
        session = self.get_session(session_id)
        if session:
            return session.history
        return None
    
    def clear_session(self, session_id: str) -> bool:
        """Clear a session's history"""
        session = self.get_session(session_id)
        if session:
            session.clear_history()
            return True
        return False
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session entirely"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False


# Global chatbot instance
chatbot = ChatbotEngine()