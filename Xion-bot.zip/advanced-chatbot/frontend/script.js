/**
 * Advanced AI Chatbot - Frontend JavaScript
 * Handles all UI interactions, API communication, and state management
 */

// ============================================
// Configuration & State
// ============================================

const CONFIG = {
    API_ENDPOINT: localStorage.getItem('apiEndpoint') || 'http://localhost:5000',
    DEFAULT_SESSION_ID: null,
    MAX_RETRIES: 3,
    RETRY_DELAY: 1000
};

const state = {
    sessionId: null,
    isTyping: false,
    messageHistory: [],
    settings: {
        theme: localStorage.getItem('theme') || 'dark',
        soundEnabled: localStorage.getItem('soundEnabled') === 'true',
        autoScroll: localStorage.getItem('autoScroll') !== 'false'
    },
    sidebarOpen: false
};

// ============================================
// DOM Elements
// ============================================

const elements = {
    // Sidebar
    sidebar: document.getElementById('sidebar'),
    newChatBtn: document.getElementById('newChatBtn'),
    chatHistory: document.getElementById('chatHistory'),
    todayChats: document.getElementById('todayChats'),
    previousChats: document.getElementById('previousChats'),
    settingsBtn: document.getElementById('settingsBtn'),
    connectionStatus: document.getElementById('connectionStatus'),
    
    // Mobile
    menuToggle: document.getElementById('menuToggle'),
    newChatMobile: document.getElementById('newChatMobile'),
    mobileHeader: document.querySelector('.mobile-header'),
    
    // Chat
    chatContainer: document.getElementById('chatContainer'),
    welcomeScreen: document.getElementById('welcomeScreen'),
    messagesArea: document.getElementById('messagesArea'),
    
    // Input
    messageInput: document.getElementById('messageInput'),
    sendBtn: document.getElementById('sendBtn'),
    attachBtn: document.getElementById('attachBtn'),
    charCount: document.getElementById('charCount'),
    
    // Settings Modal
    settingsModal: document.getElementById('settingsModal'),
    closeSettings: document.getElementById('closeSettings'),
    apiEndpoint: document.getElementById('apiEndpoint'),
    themeSelect: document.getElementById('themeSelect'),
    soundToggle: document.getElementById('soundToggle'),
    autoScrollToggle: document.getElementById('autoScrollToggle'),
    resetSettings: document.getElementById('resetSettings'),
    saveSettings: document.getElementById('saveSettings'),
    
    // Toast & Loading
    toastContainer: document.getElementById('toastContainer'),
    loadingOverlay: document.getElementById('loadingOverlay')
};

// ============================================
// Initialization
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    // Apply saved theme
    applyTheme(state.settings.theme);
    
    // Load settings into modal
    loadSettingsIntoModal();
    
    // Check API connection
    checkConnection();
    
    // Setup event listeners
    setupEventListeners();
    
    // Auto-resize textarea
    autoResizeTextarea();
    
    // Create sidebar overlay for mobile
    createSidebarOverlay();
    
    // Start connection status polling
    setInterval(checkConnection, 30000);
}

function createSidebarOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.id = 'sidebarOverlay';
    overlay.addEventListener('click', closeSidebar);
    document.body.appendChild(overlay);
    elements.sidebarOverlay = overlay;
}

// ============================================
// Event Listeners
// ============================================

function setupEventListeners() {
    // Send message
    elements.sendBtn.addEventListener('click', sendMessage);
    elements.messageInput.addEventListener('keydown', handleInputKeydown);
    elements.messageInput.addEventListener('input', handleInputChange);
    
    // New chat
    elements.newChatBtn.addEventListener('click', startNewChat);
    elements.newChatMobile.addEventListener('click', startNewChat);
    
    // Mobile menu
    elements.menuToggle.addEventListener('click', toggleSidebar);
    
    // Settings
    elements.settingsBtn.addEventListener('click', openSettings);
    elements.closeSettings.addEventListener('click', closeSettings);
    elements.settingsModal.addEventListener('click', (e) => {
        if (e.target === elements.settingsModal) closeSettings();
    });
    elements.saveSettings.addEventListener('click', saveSettings);
    elements.resetSettings.addEventListener('click', resetSettings);
    
    // Suggestion chips
    document.querySelectorAll('.chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const message = chip.dataset.message;
            elements.messageInput.value = message;
            handleInputChange();
            sendMessage();
        });
    });
    
    // Attach button (placeholder)
    elements.attachBtn.addEventListener('click', () => {
        showToast('File attachment coming soon!', 'info');
    });
}

function handleInputKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

function handleInputChange() {
    const length = elements.messageInput.value.length;
    elements.charCount.textContent = `${length}/4000`;
    elements.sendBtn.disabled = length === 0 || state.isTyping;
    
    // Auto-resize
    autoResizeTextarea();
}

function autoResizeTextarea() {
    const textarea = elements.messageInput;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
}

// ============================================
// API Communication
// ============================================

async function sendMessage() {
    const message = elements.messageInput.value.trim();
    if (!message || state.isTyping) return;
    
    // Hide welcome screen
    elements.welcomeScreen.style.display = 'none';
    
    // Add user message to UI
    addMessageToUI('user', message);
    
    // Clear input
    elements.messageInput.value = '';
    handleInputChange();
    
    // Show typing indicator
    showTypingIndicator();
    
    // Disable send button
    state.isTyping = true;
    elements.sendBtn.disabled = true;
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                session_id: state.sessionId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Update session ID
            state.sessionId = data.data.session_id;
            
            // Save to history
            state.messageHistory.push(
                { role: 'user', content: message },
                { role: 'assistant', content: data.data.response }
            );
            
            // Remove typing indicator and add bot response
            removeTypingIndicator();
            addMessageToUI('bot', data.data.response);
            
            // Play sound if enabled
            if (state.settings.soundEnabled) {
                playMessageSound();
            }
            
            // Update chat history sidebar
            updateChatHistory();
        } else {
            throw new Error(data.error || 'Failed to get response');
        }
        
    } catch (error) {
        removeTypingIndicator();
        addMessageToUI('bot', `Sorry, I encountered an error: ${error.message}. Please check your connection and try again.`);
        showToast('Failed to send message', 'error');
        console.error('Chat error:', error);
    } finally {
        state.isTyping = false;
        elements.sendBtn.disabled = elements.messageInput.value.length === 0;
    }
}

async function checkConnection() {
    const statusDot = elements.connectionStatus.querySelector('.status-dot');
    const statusText = elements.connectionStatus.querySelector('.status-text');
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/health`, {
            method: 'GET',
            timeout: 5000
        });
        
        const data = await response.json();
        
        if (data.status === 'healthy') {
            statusDot.className = 'status-dot connected';
            statusText.textContent = data.ai_enabled ? 'Connected (AI)' : 'Connected (Fallback)';
        } else {
            throw new Error('Unhealthy response');
        }
        
    } catch (error) {
        statusDot.className = 'status-dot error';
        statusText.textContent = 'Disconnected';
    }
}

// ============================================
// UI Functions
// ============================================

function addMessageToUI(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = role === 'user' ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
    
    const contentWrapper = document.createElement('div');
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    messageContent.innerHTML = formatMessage(content);
    
    const messageTime = document.createElement('div');
    messageTime.className = 'message-time';
    messageTime.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    contentWrapper.appendChild(messageContent);
    contentWrapper.appendChild(messageTime);
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentWrapper);
    
    elements.messagesArea.appendChild(messageDiv);
    
    // Auto-scroll
    if (state.settings.autoScroll) {
        scrollToBottom();
    }
}

function formatMessage(content) {
    // Escape HTML
    let formatted = content
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    
    // Format code blocks
    formatted = formatted.replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>');
    formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // Format bold and italic
    formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    
    // Format links
    formatted = formatted.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
    
    // Convert newlines to breaks
    formatted = formatted.replace(/\n/g, '<br>');
    
    return formatted;
}

function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot typing';
    typingDiv.id = 'typingIndicator';
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = '<i class="fas fa-robot"></i>';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    content.innerHTML = `
        <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    
    typingDiv.appendChild(avatar);
    typingDiv.appendChild(content);
    
    elements.messagesArea.appendChild(typingDiv);
    
    if (state.settings.autoScroll) {
        scrollToBottom();
    }
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function scrollToBottom() {
    elements.chatContainer.scrollTop = elements.chatContainer.scrollHeight;
}

function startNewChat() {
    // Clear session
    state.sessionId = null;
    state.messageHistory = [];
    
    // Clear UI
    elements.messagesArea.innerHTML = '';
    elements.welcomeScreen.style.display = 'flex';
    elements.todayChats.innerHTML = '';
    elements.previousChats.innerHTML = '';
    
    // Close sidebar on mobile
    closeSidebar();
    
    showToast('New chat started', 'success');
}

function updateChatHistory() {
    if (state.messageHistory.length === 0) return;
    
    const firstUserMessage = state.messageHistory.find(m => m.role === 'user');
    if (!firstUserMessage) return;
    
    const title = firstUserMessage.content.substring(0, 30) + (firstUserMessage.content.length > 30 ? '...' : '');
    
    // Check if already exists
    const existingItem = document.querySelector(`[data-session-id="${state.sessionId}"]`);
    if (existingItem) return;
    
    const li = document.createElement('li');
    li.className = 'history-item';
    li.dataset.sessionId = state.sessionId;
    li.innerHTML = `
        <i class="fas fa-comment"></i>
        <span>${title}</span>
    `;
    
    elements.todayChats.appendChild(li);
}

// ============================================
// Sidebar Functions
// ============================================

function toggleSidebar() {
    state.sidebarOpen = !state.sidebarOpen;
    elements.sidebar.classList.toggle('open', state.sidebarOpen);
    elements.sidebarOverlay.classList.toggle('active', state.sidebarOpen);
}

function closeSidebar() {
    state.sidebarOpen = false;
    elements.sidebar.classList.remove('open');
    elements.sidebarOverlay.classList.remove('active');
}

// ============================================
// Settings Functions
// ============================================

function openSettings() {
    elements.settingsModal.classList.add('active');
    closeSidebar();
}

function closeSettings() {
    elements.settingsModal.classList.remove('active');
}

function loadSettingsIntoModal() {
    elements.apiEndpoint.value = CONFIG.API_ENDPOINT;
    elements.themeSelect.value = state.settings.theme;
    elements.soundToggle.checked = state.settings.soundEnabled;
    elements.autoScrollToggle.checked = state.settings.autoScroll;
}

function saveSettings() {
    // Update config
    CONFIG.API_ENDPOINT = elements.apiEndpoint.value.trim() || 'http://localhost:5000';
    state.settings.theme = elements.themeSelect.value;
    state.settings.soundEnabled = elements.soundToggle.checked;
    state.settings.autoScroll = elements.autoScrollToggle.checked;
    
    // Save to localStorage
    localStorage.setItem('apiEndpoint', CONFIG.API_ENDPOINT);
    localStorage.setItem('theme', state.settings.theme);
    localStorage.setItem('soundEnabled', state.settings.soundEnabled);
    localStorage.setItem('autoScroll', state.settings.autoScroll);
    
    // Apply theme
    applyTheme(state.settings.theme);
    
    // Test connection with new endpoint
    checkConnection();
    
    closeSettings();
    showToast('Settings saved successfully', 'success');
}

function resetSettings() {
    elements.apiEndpoint.value = 'http://localhost:5000';
    elements.themeSelect.value = 'dark';
    elements.soundToggle.checked = false;
    elements.autoScrollToggle.checked = true;
}

function applyTheme(theme) {
    if (theme === 'auto') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    } else {
        document.documentElement.setAttribute('data-theme', theme);
    }
}

// ============================================
// Toast Notifications
// ============================================

function showToast(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    }[type];
    
    toast.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ============================================
// Sound Effects
// ============================================

function playMessageSound() {
    // Simple beep using Web Audio API
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
    } catch (e) {
        console.log('Audio not supported');
    }
}

// ============================================
// Utility Functions
// ============================================

// Handle window resize
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        closeSidebar();
    }
});

// Handle visibility change (pause/resume)
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        checkConnection();
    }
});

// Export for debugging
window.chatbotApp = {
    state,
    CONFIG,
    elements,
    sendMessage,
    startNewChat,
    checkConnection
};