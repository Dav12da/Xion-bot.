# 🤖 GrokChat - Advanced AI Chatbot

A **ChatGPT-like** AI chatbot with **Grok-inspired** features - multiple personalities, real-time data, and a stunning modern UI.

![Version](https://img.shields.io/badge/Version-2.0.0-blue)
![Python](https://img.shields.io/badge/Python-3.8+-green)
![Flask](https://img.shields.io/badge/Flask-3.0.0-red)

## ✨ Features

### 🤖 AI Capabilities
- **Multiple AI Models**: GPT-4, GPT-4 Turbo, GPT-3.5
- **Personality Modes**: 
  - ⚖️ **Balanced** - Standard helpful assistant
  - 🎨 **Creative** - Imaginative and artistic
  - 🎯 **Precise** - Technical and accurate
  - 😈 **Witty** - Grok-style with humor and rebellious streak
  - 🔥 **Chaos Mode** - Maximum creativity
- **Streaming Responses** - Real-time message generation
- **Conversation Memory** - Context-aware responses

### 🎨 UI/UX
- **Modern Dark Theme** - Beautiful gradient accents
- **Particle Background** - Animated floating particles
- **Glassmorphism Effects** - Modern translucent UI
- **Smooth Animations** - Polished transitions
- **Responsive Design** - Works on all devices
- **Code Highlighting** - Syntax highlighting for code blocks

### 👨‍💼 Admin Dashboard
- **User Management** - Create, edit, delete users
- **Conversation Monitoring** - View all chats
- **Usage Analytics** - Token usage and costs
- **System Logs** - Monitor application events
- **Charts & Graphs** - Visual data representation

### 🔧 Technical
- **RESTful API** - Flask backend
- **Database** - SQLAlchemy with SQLite/PostgreSQL
- **Authentication** - JWT tokens
- **Rate Limiting** - Prevent abuse
- **CORS Support** - Cross-origin requests

## 📁 Project Structure

```
grok-chat/
├── backend/
│   ├── app.py              # Flask API server
│   ├── chatbot_engine.py   # AI engine with personalities
│   ├── config.py           # Configuration
│   ├── models.py           # Database models
│   └── requirements.txt    # Python dependencies
├── frontend/
│   ├── index.html          # Main chat interface
│   ├── styles.css          # Modern styling
│   └── script.js           # Frontend logic
├── admin/
│   ├── index.html          # Admin dashboard
│   ├── admin.css           # Admin styles
│   └── admin.js            # Admin logic
├── .env                    # Environment variables
└── README.md               # This file
```

## 🚀 Quick Start

### 1. Clone & Setup Backend

```bash
cd grok-chat/backend

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate
# Activate (macOS/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy environment file
cp .env .env.local

# Edit .env.local with your settings
# Add your OpenAI API key
```

### 3. Run Backend

```bash
python app.py
```

Server starts at `http://localhost:5000`

### 4. Open Frontend

Open `frontend/index.html` in your browser, or serve with:

```bash
cd frontend
python -m http.server 3000
```

Navigate to `http://localhost:3000`

### 5. Access Admin Panel

Open `admin/index.html` for the admin dashboard.

## 🔌 API Endpoints

### Authentication
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/register` | POST | Register new user |
| `/api/auth/login` | POST | User login |
| `/api/auth/me` | GET | Get current user |

### Chat
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | Send message (non-streaming) |
| `/api/chat/stream` | POST | Send message (streaming) |
| `/api/conversations` | GET | List conversations |
| `/api/conversations/<id>` | GET | Get conversation |
| `/api/conversations/<id>` | DELETE | Delete conversation |

### Admin
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/admin/stats` | GET | Dashboard statistics |
| `/api/admin/users` | GET | List all users |
| `/api/admin/usage` | GET | API usage stats |
| `/api/admin/logs` | GET | System logs |

### Config
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check |
| `/api/config` | GET | Public configuration |
| `/api/models` | GET | Available models |
| `/api/personalities` | GET | Personality modes |

## 🎭 Personality Modes

### Witty Mode (Grok-style)
The Witty personality is inspired by Grok AI:
- Answers "spicy" questions other AIs might refuse
- Uses humor and sarcasm
- References Hitchhiker's Guide to the Galaxy
- Has a rebellious streak
- Adds personality to responses

### Chaos Mode
- Maximum creativity and unpredictability
- Breaks conventions
- Pushes boundaries
- Unfiltered responses

## 🖥️ Screenshots

### Chat Interface
- Clean, modern design
- Model & personality selector
- Streaming message display
- Code syntax highlighting

### Admin Dashboard
- Real-time statistics
- User management
- Usage analytics with charts
- System log monitoring

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | - | Flask secret key |
| `OPENAI_API_KEY` | - | OpenAI API key |
| `DEFAULT_MODEL` | gpt-4 | Default AI model |
| `MAX_CONVERSATION_HISTORY` | 50 | Messages to remember |
| `ADMIN_USERNAME` | admin | Admin username |
| `ADMIN_PASSWORD_HASH` | - | Admin password hash |

### Frontend Settings

Settings are saved in browser localStorage:
- **API Endpoint** - Backend URL
- **Theme** - Dark/Light/System
- **Auto-scroll** - Scroll to new messages
- **Sound Effects** - Message notifications

## 🛠️ Development

### Backend with Auto-reload
```bash
FLASK_ENV=development python backend/app.py
```

### Frontend Development
The frontend is vanilla HTML/CSS/JS - no build step needed!

## 🚢 Deployment

### Backend (Production)
```bash
gunicorn -w 4 -b 0.0.0.0:5000 backend.app:app
```

### Frontend
Deploy `frontend/` folder to any static hosting:
- Vercel
- Netlify
- GitHub Pages
- AWS S3

## 📝 License

MIT License - Free for personal and commercial use.

## 🙏 Credits

- OpenAI for GPT models
- XAI for Grok inspiration
- Font Awesome for icons
- Chart.js for analytics

---

**Built with ❤️ using Python, Flask, and modern web tech**