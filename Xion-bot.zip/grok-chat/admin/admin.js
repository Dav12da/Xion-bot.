/**
 * GrokChat Admin Dashboard
 */

const CONFIG = {
    API_ENDPOINT: localStorage.getItem('apiEndpoint') || 'http://localhost:5000'
};

const state = {
    currentSection: 'dashboard',
    stats: {},
    users: [],
    conversations: [],
    logs: [],
    usage: [],
    charts: {}
};

// DOM Elements
const elements = {
    navItems: document.querySelectorAll('.nav-item'),
    sections: document.querySelectorAll('.content-section'),
    pageTitle: document.getElementById('pageTitle'),
    refreshBtn: document.getElementById('refreshBtn'),
    toastContainer: document.getElementById('toastContainer')
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeAdmin();
});

function initializeAdmin() {
    setupNavigation();
    setupEventListeners();
    loadDashboardData();
    
    // Set default dates for usage
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    document.getElementById('usageEndDate').value = today;
    document.getElementById('usageStartDate').value = weekAgo;
}

function setupNavigation() {
    elements.navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.dataset.section;
            switchSection(section);
        });
    });
}

function switchSection(section) {
    state.currentSection = section;
    
    // Update nav
    elements.navItems.forEach(item => {
        item.classList.toggle('active', item.dataset.section === section);
    });
    
    // Update sections
    elements.sections.forEach(sec => {
        sec.classList.remove('active');
    });
    document.getElementById(section + 'Section').classList.add('active');
    
    // Update title
    const titles = {
        dashboard: 'Dashboard',
        users: 'User Management',
        conversations: 'Conversations',
        usage: 'Usage Statistics',
        logs: 'System Logs',
        settings: 'Settings'
    };
    elements.pageTitle.textContent = titles[section];
    
    // Load section data
    switch(section) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'users':
            loadUsers();
            break;
        case 'conversations':
            loadConversations();
            break;
        case 'usage':
            loadUsageStats();
            break;
        case 'logs':
            loadLogs();
            break;
    }
}

function setupEventListeners() {
    elements.refreshBtn.addEventListener('click', () => {
        switchSection(state.currentSection);
        showToast('Data refreshed', 'success');
    });
    
    document.getElementById('logoutBtn').addEventListener('click', logout);
    document.getElementById('saveSettings').addEventListener('click', saveSettings);
    document.getElementById('resetSettings').addEventListener('click', resetSettings);
    document.getElementById('applyDateRange').addEventListener('click', loadUsageStats);
    document.getElementById('clearLogsBtn').addEventListener('click', clearOldLogs);
    
    // Range input
    const tempRange = document.getElementById('temperature');
    if (tempRange) {
        tempRange.addEventListener('input', (e) => {
            e.target.nextElementSibling.textContent = e.target.value;
        });
    }
}

// Data Loading
async function loadDashboardData() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/admin/stats`);
        const data = await response.json();
        
        if (data.success) {
            state.stats = data.data;
            
            // Update stats
            document.getElementById('totalUsers').textContent = data.data.total_users;
            document.getElementById('totalConversations').textContent = data.data.total_conversations;
            document.getElementById('totalMessages').textContent = data.data.total_messages;
            document.getElementById('todayMessages').textContent = data.data.today_messages;
            
            // Update activity list
            const activityList = document.getElementById('activityList');
            activityList.innerHTML = '';
            
            data.data.recent_conversations.forEach(conv => {
                const item = document.createElement('div');
                item.className = 'activity-item';
                item.innerHTML = `
                    <div class="activity-icon">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="activity-content">
                        <p>New conversation: ${conv.title}</p>
                        <span>${formatDate(conv.updated_at)}</span>
                    </div>
                `;
                activityList.appendChild(item);
            });
            
            // Update charts
            updateCharts();
        }
    } catch (error) {
        console.error('Failed to load dashboard:', error);
    }
}

async function loadUsers() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/admin/users`);
        const data = await response.json();
        
        if (data.success) {
            state.users = data.data.users;
            renderUsersTable();
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

function renderUsersTable() {
    const tbody = document.querySelector('#usersTable tbody');
    tbody.innerHTML = '';
    
    state.users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.username}</td>
            <td>${user.email || '-'}</td>
            <td><span class="badge badge-${user.is_admin ? 'admin' : 'user'}">${user.is_admin ? 'Admin' : 'User'}</span></td>
            <td><span class="badge badge-${user.is_active ? 'active' : 'inactive'}">${user.is_active ? 'Active' : 'Inactive'}</span></td>
            <td>${formatDate(user.created_at)}</td>
            <td>${user.last_login ? formatDate(user.last_login) : 'Never'}</td>
            <td>
                <button class="btn btn-sm btn-secondary" onclick="editUser('${user.id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteUser('${user.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

async function loadConversations() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/conversations`);
        const data = await response.json();
        
        if (data.success) {
            state.conversations = data.data.conversations;
            renderConversationsTable();
        }
    } catch (error) {
        console.error('Failed to load conversations:', error);
    }
}

function renderConversationsTable() {
    const tbody = document.querySelector('#conversationsTable tbody');
    tbody.innerHTML = '';
    
    state.conversations.forEach(conv => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${conv.title}</td>
            <td>${conv.model}</td>
            <td>${conv.personality}</td>
            <td>${conv.message_count}</td>
            <td>${formatDate(conv.created_at)}</td>
            <td>${formatDate(conv.updated_at)}</td>
            <td>
                <button class="btn btn-sm btn-secondary" onclick="viewConversation('${conv.id}')">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteConversation('${conv.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

async function loadUsageStats() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/admin/usage`);
        const data = await response.json();
        
        if (data.success) {
            state.usage = data.data.usage;
            
            // Calculate totals
            let totalTokens = 0;
            let inputTokens = 0;
            let outputTokens = 0;
            
            state.usage.forEach(u => {
                totalTokens += u.tokens_input + u.tokens_output;
                inputTokens += u.tokens_input;
                outputTokens += u.tokens_output;
            });
            
            document.getElementById('totalTokens').textContent = totalTokens.toLocaleString();
            document.getElementById('inputTokens').textContent = inputTokens.toLocaleString();
            document.getElementById('outputTokens').textContent = outputTokens.toLocaleString();
            document.getElementById('estimatedCost').textContent = '$' + (totalTokens * 0.00002).toFixed(2);
            
            // Update chart
            updateUsageChart();
        }
    } catch (error) {
        console.error('Failed to load usage:', error);
    }
}

async function loadLogs() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/admin/logs`);
        const data = await response.json();
        
        if (data.success) {
            state.logs = data.data.logs;
            renderLogs();
        }
    } catch (error) {
        console.error('Failed to load logs:', error);
    }
}

function renderLogs() {
    const container = document.getElementById('logsContainer');
    container.innerHTML = '';
    
    const filter = document.getElementById('logLevelFilter').value;
    
    state.logs.forEach(log => {
        if (filter !== 'all' && log.level !== filter) return;
        
        const item = document.createElement('div');
        item.className = 'log-item';
        item.innerHTML = `
            <span class="log-time">${formatDate(log.created_at)}</span>
            <span class="log-level ${log.level.toLowerCase()}">${log.level}</span>
            <span class="log-message">${log.message}</span>
        `;
        container.appendChild(item);
    });
}

// Charts
function updateCharts() {
    // Usage Chart
    const usageCtx = document.getElementById('usageChart').getContext('2d');
    
    if (state.charts.usage) {
        state.charts.usage.destroy();
    }
    
    state.charts.usage = new Chart(usageCtx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Messages',
                data: [65, 78, 90, 81, 96, 85, 100],
                borderColor: '#10a37f',
                backgroundColor: 'rgba(16, 163, 127, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#2a2a2a' }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
    
    // Model Chart
    const modelCtx = document.getElementById('modelChart').getContext('2d');
    
    if (state.charts.model) {
        state.charts.model.destroy();
    }
    
    state.charts.model = new Chart(modelCtx, {
        type: 'doughnut',
        data: {
            labels: ['GPT-4', 'GPT-4 Turbo', 'GPT-3.5'],
            datasets: [{
                data: [45, 30, 25],
                backgroundColor: ['#10a37f', '#19c59f', '#3b82f6']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#a0a0a0' }
                }
            }
        }
    });
}

function updateUsageChart() {
    const ctx = document.getElementById('dailyUsageChart').getContext('2d');
    
    if (state.charts.daily) {
        state.charts.daily.destroy();
    }
    
    state.charts.daily = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: state.usage.map(u => formatDate(u.timestamp)).slice(-7),
            datasets: [{
                label: 'Tokens',
                data: state.usage.map(u => u.tokens_input + u.tokens_output).slice(-7),
                backgroundColor: '#10a37f'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#2a2a2a' }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// Actions
function editUser(id) {
    showToast('Edit user: ' + id, 'info');
}

async function deleteUser(id) {
    if (!confirm('Delete this user?')) return;
    showToast('User deleted', 'success');
    loadUsers();
}

function viewConversation(id) {
    window.open(`../frontend/index.html?conversation=${id}`, '_blank');
}

async function deleteConversation(id) {
    if (!confirm('Delete this conversation?')) return;
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/conversations/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showToast('Conversation deleted', 'success');
            loadConversations();
        }
    } catch (error) {
        showToast('Failed to delete', 'error');
    }
}

function clearOldLogs() {
    showToast('Old logs cleared', 'success');
    loadLogs();
}

function saveSettings() {
    showToast('Settings saved', 'success');
}

function resetSettings() {
    showToast('Settings reset', 'info');
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '../frontend/index.html';
}

// Utilities
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}