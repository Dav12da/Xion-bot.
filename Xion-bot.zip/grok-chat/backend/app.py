"""
GrokChat - Flask Backend API
"""
from flask import Flask, request, jsonify, stream_with_context, Response
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import json
import time
import uuid

from config import Config
from models import db, User, Conversation, Message, ApiUsage, SystemLog
from chatbot_engine import ai_engine

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db.init_app(app)
jwt = JWTManager(app)
CORS(app, origins=Config.CORS_ORIGINS)

# Create tables
with app.app_context():
    db.create_all()

# ============================================
# Middleware & Helpers
# ============================================

@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    if hasattr(request, 'start_time'):
        elapsed = time.time() - request.start_time
        response.headers['X-Response-Time'] = f'{elapsed:.3f}s'
    return response

def log_event(level, message, source=None, user_id=None, metadata=None):
    """Log system events"""
    try:
        log = SystemLog(
            level=level,
            message=message,
            source=source,
            user_id=user_id,
            metadata_json=json.dumps(metadata) if metadata else None
        )
        db.session.add(log)
        db.session.commit()
    except:
        db.session.rollback()

def track_usage(user_id, endpoint, tokens_in=0, tokens_out=0, cost=0.0):
    """Track API usage"""
    try:
        usage = ApiUsage(
            user_id=user_id,
            endpoint=endpoint,
            tokens_input=tokens_in,
            tokens_output=tokens_out,
            cost=cost
        )
        db.session.add(usage)
        db.session.commit()
    except:
        db.session.rollback()

# ============================================
# Authentication Routes
# ============================================

@app.route('/api/auth/register', methods=['POST'])
def register():
    """Register new user"""
    data = request.get_json()
    
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'success': False, 'error': 'Username and password required'}), 400
    
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'success': False, 'error': 'Username already exists'}), 409
    
    try:
        user = User(
            username=data['username'],
            email=data.get('email'),
            password_hash=generate_password_hash(data['password']),
            is_admin=data.get('is_admin', False)
        )
        db.session.add(user)
        db.session.commit()
        
        log_event('INFO', f'New user registered: {user.username}', 'auth')
        
        return jsonify({
            'success': True,
            'data': {'user': user.to_dict()}
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    """User login"""
    data = request.get_json()
    
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'success': False, 'error': 'Username and password required'}), 400
    
    user = User.query.filter_by(username=data['username']).first()
    
    if not user or not check_password_hash(user.password_hash, data['password']):
        return jsonify({'success': False, 'error': 'Invalid credentials'}), 401
    
    if not user.is_active:
        return jsonify({'success': False, 'error': 'Account disabled'}), 403
    
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    access_token = create_access_token(identity=user.id)
    
    log_event('INFO', f'User logged in: {user.username}', 'auth', user.id)
    
    return jsonify({
        'success': True,
        'data': {
            'access_token': access_token,
            'user': user.to_dict()
        }
    })

@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get current user info"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'success': False, 'error': 'User not found'}), 404
    
    return jsonify({
        'success': True,
        'data': {'user': user.to_dict()}
    })

# ============================================
# Chat Routes
# ============================================

@app.route('/api/chat', methods=['POST'])
def chat():
    """Send message and get AI response"""
    data = request.get_json()
    
    if not data or not data.get('message'):
        return jsonify({'success': False, 'error': 'Message is required'}), 400
    
    message = data['message'].strip()
    conversation_id = data.get('conversation_id')
    model = data.get('model', Config.DEFAULT_MODEL)
    personality = data.get('personality', 'balanced')
    stream = data.get('stream', False)
    
    # Get or create conversation
    conversation = None
    if conversation_id:
        conversation = Conversation.query.get(conversation_id)
    
    if not conversation:
        conversation = Conversation(
            title=message[:50] + '...' if len(message) > 50 else message,
            model=model,
            personality=personality
        )
        db.session.add(conversation)
        db.session.commit()
    
    # Save user message
    user_msg = Message(
        conversation_id=conversation.id,
        role='user',
        content=message
    )
    db.session.add(user_msg)
    db.session.commit()
    
    # Get conversation history
    history = Message.query.filter_by(conversation_id=conversation.id).order_by(Message.created_at).all()
    messages = [{'role': m.role, 'content': m.content} for m in history if m.role in ['user', 'assistant']]
    
    if stream:
        # Streaming response
        def generate():
            full_response = []
            for chunk in ai_engine.generate_response(messages, model, personality, stream=True):
                full_response.append(chunk)
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"
            
            # Save complete response
            complete = ''.join(full_response)
            assistant_msg = Message(
                conversation_id=conversation.id,
                role='assistant',
                content=complete,
                model=model
            )
            db.session.add(assistant_msg)
            conversation.updated_at = datetime.utcnow()
            db.session.commit()
            
            yield f"data: {json.dumps({'done': True, 'conversation_id': conversation.id})}\n\n"
        
        return Response(stream_with_context(generate()), mimetype='text/event-stream')
    
    else:
        # Non-streaming response
        response_text = ''
        for chunk in ai_engine.generate_response(messages, model, personality, stream=False):
            response_text += chunk
        
        # Save assistant message
        assistant_msg = Message(
            conversation_id=conversation.id,
            role='assistant',
            content=response_text,
            model=model
        )
        db.session.add(assistant_msg)
        conversation.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': {
                'response': response_text,
                'conversation_id': conversation.id,
                'model': model,
                'personality': personality
            }
        })

@app.route('/api/chat/stream', methods=['POST'])
def chat_stream():
    """Streaming chat endpoint"""
    data = request.get_json()
    
    if not data or not data.get('message'):
        return jsonify({'success': False, 'error': 'Message is required'}), 400
    
    message = data['message'].strip()
    conversation_id = data.get('conversation_id')
    model = data.get('model', Config.DEFAULT_MODEL)
    personality = data.get('personality', 'balanced')
    
    # Get or create conversation
    conversation = None
    if conversation_id:
        conversation = Conversation.query.get(conversation_id)
    
    if not conversation:
        conversation = Conversation(
            title=message[:50] + '...' if len(message) > 50 else message,
            model=model,
            personality=personality
        )
        db.session.add(conversation)
        db.session.commit()
    
    # Save user message
    user_msg = Message(
        conversation_id=conversation.id,
        role='user',
        content=message
    )
    db.session.add(user_msg)
    db.session.commit()
    
    # Get conversation history
    history = Message.query.filter_by(conversation_id=conversation.id).order_by(Message.created_at).all()
    messages = [{'role': m.role, 'content': m.content} for m in history if m.role in ['user', 'assistant']]
    
    def generate():
        full_response = []
        for chunk in ai_engine.generate_response(messages, model, personality, stream=True):
            full_response.append(chunk)
            yield f"data: {json.dumps({'chunk': chunk})}\n\n"
        
        # Save complete response
        complete = ''.join(full_response)
        assistant_msg = Message(
            conversation_id=conversation.id,
            role='assistant',
            content=complete,
            model=model
        )
        db.session.add(assistant_msg)
        conversation.updated_at = datetime.utcnow()
        db.session.commit()
        
        yield f"data: {json.dumps({'done': True, 'conversation_id': conversation.id})}\n\n"
    
    return Response(stream_with_context(generate()), mimetype='text/event-stream')

@app.route('/api/conversations', methods=['GET'])
def get_conversations():
    """Get all conversations"""
    conversations = Conversation.query.filter_by(is_archived=False).order_by(Conversation.updated_at.desc()).all()
    
    return jsonify({
        'success': True,
        'data': {
            'conversations': [c.to_dict() for c in conversations]
        }
    })

@app.route('/api/conversations/<conversation_id>', methods=['GET'])
def get_conversation(conversation_id):
    """Get single conversation with messages"""
    conversation = Conversation.query.get(conversation_id)
    
    if not conversation:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    
    return jsonify({
        'success': True,
        'data': {
            'conversation': conversation.to_dict(include_messages=True)
        }
    })

@app.route('/api/conversations/<conversation_id>', methods=['DELETE'])
def delete_conversation(conversation_id):
    """Delete conversation"""
    conversation = Conversation.query.get(conversation_id)
    
    if not conversation:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    
    db.session.delete(conversation)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Conversation deleted'
    })

@app.route('/api/conversations/<conversation_id>/clear', methods=['POST'])
def clear_conversation(conversation_id):
    """Clear conversation messages"""
    conversation = Conversation.query.get(conversation_id)
    
    if not conversation:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    
    Message.query.filter_by(conversation_id=conversation_id).delete()
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Conversation cleared'
    })

# ============================================
# Personality & Models
# ============================================

@app.route('/api/personalities', methods=['GET'])
def get_personalities():
    """Get available personality modes"""
    return jsonify({
        'success': True,
        'data': {
            'personalities': Config.PERSONALITY_MODES
        }
    })

@app.route('/api/models', methods=['GET'])
def get_models():
    """Get available AI models"""
    return jsonify({
        'success': True,
        'data': {
            'models': Config.AVAILABLE_MODELS,
            'default': Config.DEFAULT_MODEL
        }
    })

# ============================================
# Admin Routes
# ============================================

@app.route('/api/admin/stats', methods=['GET'])
def admin_stats():
    """Get admin dashboard stats"""
    total_users = User.query.count()
    total_conversations = Conversation.query.count()
    total_messages = Message.query.count()
    
    # Recent activity
    recent_conversations = Conversation.query.order_by(Conversation.updated_at.desc()).limit(10).all()
    
    # Usage stats
    today = datetime.utcnow().date()
    today_messages = Message.query.filter(db.func.date(Message.created_at) == today).count()
    
    return jsonify({
        'success': True,
        'data': {
            'total_users': total_users,
            'total_conversations': total_conversations,
            'total_messages': total_messages,
            'today_messages': today_messages,
            'recent_conversations': [c.to_dict() for c in recent_conversations]
        }
    })

@app.route('/api/admin/users', methods=['GET'])
def admin_users():
    """Get all users for admin"""
    users = User.query.all()
    
    return jsonify({
        'success': True,
        'data': {
            'users': [u.to_dict() for u in users]
        }
    })

@app.route('/api/admin/logs', methods=['GET'])
def admin_logs():
    """Get system logs"""
    logs = SystemLog.query.order_by(SystemLog.created_at.desc()).limit(100).all()
    
    return jsonify({
        'success': True,
        'data': {
            'logs': [l.to_dict() for l in logs]
        }
    })

@app.route('/api/admin/usage', methods=['GET'])
def admin_usage():
    """Get API usage statistics"""
    usage = ApiUsage.query.order_by(ApiUsage.timestamp.desc()).limit(100).all()
    
    return jsonify({
        'success': True,
        'data': {
            'usage': [u.to_dict() for u in usage]
        }
    })

# ============================================
# Health & Info
# ============================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '2.0.0',
        'ai_enabled': ai_engine.openai_client is not None,
        'features': {
            'streaming': True,
            'multiple_models': True,
            'personality_modes': True,
            'realtime_data': Config.ENABLE_REALTIME
        }
    })

@app.route('/api/config', methods=['GET'])
def get_config():
    """Get public configuration"""
    return jsonify({
        'success': True,
        'data': {
            'app_name': 'GrokChat',
            'version': '2.0.0',
            'features': {
                'auth': True,
                'streaming': True,
                'personalities': list(Config.PERSONALITY_MODES.keys()),
                'models': Config.AVAILABLE_MODELS
            }
        }
    })

# ============================================
# Error Handlers
# ============================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'success': False, 'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'success': False, 'error': 'Internal server error'}), 500

# ============================================
# Main
# ============================================

if __name__ == '__main__':
    warnings = Config.validate()
    for warning in warnings:
        print(f"⚠️  {warning}")
    
    print(f"""
    ╔══════════════════════════════════════════════════════════════╗
    ║                    🤖 GrokChat Server v2.0                   ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Server: http://{Config.HOST}:{Config.PORT}                            ║
    ║  AI: {'✅ Enabled' if ai_engine.openai_client else '⚠️  Fallback Mode'}                          ║
    ║  Personalities: {', '.join(Config.PERSONALITY_MODES.keys())}        ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)