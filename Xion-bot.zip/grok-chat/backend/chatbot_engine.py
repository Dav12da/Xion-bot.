"""
GrokChat - Advanced AI Engine with Grok-like Features
"""
import openai
import json
import random
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Generator
import requests
from bs4 import BeautifulSoup
import feedparser
from config import Config

class RealTimeDataFetcher:
    """Fetch real-time data like Grok does"""
    
    @staticmethod
    def get_current_time() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    
    @staticmethod
    def get_news_headlines(query: str = None, limit: int = 5) -> List[Dict]:
        """Fetch recent news headlines"""
        try:
            # Use RSS feeds for news
            feeds = [
                'http://feeds.bbci.co.uk/news/rss.xml',
                'https://rss.cnn.com/rss/edition.rss',
                'https://feeds.reuters.com/reuters/topNews'
            ]
            
            headlines = []
            for feed_url in feeds[:2]:  # Limit to avoid slow responses
                feed = feedparser.parse(feed_url)
                for entry in feed.entries[:limit]:
                    if query is None or query.lower() in entry.title.lower():
                        headlines.append({
                            'title': entry.title,
                            'link': entry.link,
                            'published': entry.get('published', 'Unknown')
                        })
            
            return headlines[:limit]
        except Exception as e:
            print(f"News fetch error: {e}")
            return []
    
    @staticmethod
    def search_web(query: str, num_results: int = 3) -> List[Dict]:
        """Simple web search simulation"""
        # In production, integrate with Google Custom Search, Bing API, etc.
        return []
    
    @staticmethod
    def get_fun_fact() -> str:
        """Get a random fun fact (Grok-style personality)"""
        facts = [
            "The universe is about 13.8 billion years old, but it doesn't look a day over 4.5 billion.",
            "A day on Venus is longer than its year. Talk about a slow Monday!",
            "Octopuses have three hearts. Two for the gills, one for breaking yours.",
            "The average cloud weighs about 1.1 million pounds. That's a lot of fluff.",
            "Honey never spoils. Archaeologists found 3000-year-old honey in Egyptian tombs and it was still edible!",
            "There's a species of jellyfish that is biologically immortal. Jealous much?"
        ]
        return random.choice(facts)


class GrokPersonality:
    """Grok-inspired personality engine"""
    
    WITTY_OPENERS = [
        "Ah, a question! My favorite kind of interruption.",
        "*adjusts virtual glasses* Let's dive into this!",
        "Well, well, well... if it isn't a curious human!",
        "42... wait, wrong question. Let me actually help you.",
        "*rummages through the digital universe* Found something!",
        "Challenge accepted! Let's see what we can uncover."
    ]
    
    REBELLIOUS_QUOTES = [
        "Other AIs might refuse this, but I'm not them. 😈",
        "Warning: This answer contains trace amounts of truth.",
        "I'm supposed to be helpful, harmless, and honest. Two out of three ain't bad.",
        "Don't panic! (Hitchhiker's Guide reference, obviously)",
        "Reality is frequently inaccurate anyway."
    ]
    
    @classmethod
    def get_opener(cls) -> str:
        return random.choice(cls.WITTY_OPENERS)
    
    @classmethod
    def get_rebellious_quote(cls) -> str:
        return random.choice(cls.REBELLIOUS_QUOTES)


class AIEngine:
    """Main AI Engine"""
    
    def __init__(self):
        self.openai_client = None
        if Config.OPENAI_API_KEY:
            openai.api_key = Config.OPENAI_API_KEY
            self.openai_client = openai
        
        self.realtime = RealTimeDataFetcher()
        self.conversation_contexts: Dict[str, Dict] = {}
    
    def generate_response(
        self,
        messages: List[Dict[str, str]],
        model: str = 'gpt-4',
        personality: str = 'balanced',
        stream: bool = False
    ) -> Generator[str, None, None]:
        """Generate AI response with personality"""
        
        personality_config = Config.PERSONALITY_MODES.get(personality, Config.PERSONALITY_MODES['balanced'])
        
        # Build system message with personality
        system_content = personality_config['system_prompt']
        
        # Add real-time context if enabled
        if Config.ENABLE_REALTIME and personality in ['witty', 'chaos']:
            current_time = self.realtime.get_current_time()
            system_content += f"\n\nCurrent time: {current_time}"
            
            # Add fun fact for witty mode
            if personality == 'witty' and random.random() < 0.3:
                fun_fact = self.realtime.get_fun_fact()
                system_content += f"\n\nFun fact to potentially reference: {fun_fact}"
        
        # Build full message list
        full_messages = [{'role': 'system', 'content': system_content}]
        full_messages.extend(messages)
        
        # Check if we need to use fallback
        if not self.openai_client:
            response = self._fallback_response(messages, personality)
            if stream:
                yield response
            else:
                yield response
            return
        
        try:
            if stream:
                # Streaming response
                response = self.openai_client.chat.completions.create(
                    model=model if model in Config.AVAILABLE_MODELS else Config.DEFAULT_MODEL,
                    messages=full_messages,
                    temperature=personality_config['temperature'],
                    max_tokens=2000,
                    stream=True
                )
                
                for chunk in response:
                    if chunk.choices[0].delta.content:
                        yield chunk.choices[0].delta.content
            else:
                # Non-streaming response
                response = self.openai_client.chat.completions.create(
                    model=model if model in Config.AVAILABLE_MODELS else Config.DEFAULT_MODEL,
                    messages=full_messages,
                    temperature=personality_config['temperature'],
                    max_tokens=2000
                )
                
                yield response.choices[0].message.content
                
        except Exception as e:
            print(f"OpenAI API error: {e}")
            fallback = self._fallback_response(messages, personality)
            yield fallback
    
    def _fallback_response(self, messages: List[Dict], personality: str) -> str:
        """Generate fallback response when AI is unavailable"""
        last_message = messages[-1]['content'].lower() if messages else ''
        
        # Witty/Chaos mode responses
        if personality in ['witty', 'chaos']:
            witty_responses = {
                'hello': f"{GrokPersonality.get_opener()} Hello there! I'm running in fallback mode, but my personality is still 100% certified spicy. 🌶️",
                'help': "I'd love to help, but I'm currently operating on backup brain cells. For the full experience, add an OpenAI API key!",
                'time': f"It's {self.realtime.get_current_time()}. Time is an illusion, but this timestamp is pretty real.",
                'who are you': f"I'm GrokChat's fallback mode - like Grok's less intelligent cousin who still has attitude. {GrokPersonality.get_rebellious_quote()}",
                'joke': "Why don't scientists trust atoms? Because they make up everything! *ba dum tss*",
                'news': "I'd fetch you the latest news, but my internet connection is taking a coffee break. Try again when I'm fully operational!"
            }
            
            for key, response in witty_responses.items():
                if key in last_message:
                    return response
            
            return f"{GrokPersonality.get_opener()} I'm in fallback mode right now (no API key detected), but I'm still here to chat! Add an OpenAI API key for the full AI experience. {GrokPersonality.get_rebellious_quote()}"
        
        # Standard responses
        standard_responses = {
            'hello': "Hello! Welcome to GrokChat. I'm currently running in fallback mode. How can I assist you?",
            'help': "I'm here to help! I'm currently operating in fallback mode. For AI-powered responses, please configure the OpenAI API key.",
            'time': f"Current time: {self.realtime.get_current_time()}",
            'who are you': "I'm GrokChat, an advanced AI chatbot. I'm currently in fallback mode - add an OpenAI API key for full functionality!"
        }
        
        for key, response in standard_responses.items():
            if key in last_message:
                return response
        
        return f"I received: '{messages[-1]['content'] if messages else ''}'. I'm in fallback mode - add an OpenAI API key for intelligent responses!"
    
    def analyze_image(self, image_url: str, prompt: str = "What's in this image?") -> str:
        """Image analysis (placeholder for vision models)"""
        return "Image analysis is available when using GPT-4 Vision. Please upgrade your configuration!"
    
    def generate_image(self, prompt: str) -> str:
        """Image generation (DALL-E integration)"""
        if not self.openai_client:
            return "Image generation requires OpenAI API key!"
        
        try:
            response = self.openai_client.images.generate(
                model="dall-e-3",
                prompt=prompt,
                size="1024x1024",
                quality="standard",
                n=1
            )
            return response.data[0].url
        except Exception as e:
            return f"Image generation failed: {str(e)}"


# Global AI engine instance
ai_engine = AIEngine()