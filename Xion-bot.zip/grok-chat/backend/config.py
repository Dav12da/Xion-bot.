"""
GrokChat - Advanced Configuration
"""
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Base configuration"""
    
    # Flask
    SECRET_KEY = os.getenv('SECRET_KEY', 'super-secret-key-change-in-production')
    DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'
    PORT = int(os.getenv('PORT', 5000))
    HOST = os.getenv('HOST', '0.0.0.0')
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///grokchat.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # JWT
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key')
    JWT_ACCESS_TOKEN_EXPIRES = int(os.getenv('JWT_ACCESS_TOKEN_EXPIRES', '86400'))
    
    # OpenAI
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    OPENAI_ORG_ID = os.getenv('OPENAI_ORG_ID', '')
    
    # Grok/XAI (if available)
    XAI_API_KEY = os.getenv('XAI_API_KEY', '')
    
    # AI Models
    DEFAULT_MODEL = os.getenv('DEFAULT_MODEL', 'gpt-4')
    AVAILABLE_MODELS = [
        'gpt-4',
        'gpt-4-turbo-preview',
        'gpt-3.5-turbo',
        'grok-1'  # Placeholder for XAI models
    ]
    
    # Personality Modes (Grok-inspired)
    PERSONALITY_MODES = {
        'balanced': {
            'name': 'Balanced',
            'description': 'Standard helpful assistant',
            'system_prompt': 'You are a helpful, harmless, and honest AI assistant.',
            'temperature': 0.7,
            'icon': '⚖️'
        },
        'creative': {
            'name': 'Creative',
            'description': 'Imaginative and artistic responses',
            'system_prompt': 'You are a creative AI assistant with a vivid imagination. Think outside the box and provide innovative, artistic responses.',
            'temperature': 0.9,
            'icon': '🎨'
        },
        'precise': {
            'name': 'Precise',
            'description': 'Accurate and technical answers',
            'system_prompt': 'You are a precise AI assistant focused on accuracy and technical correctness. Provide detailed, well-researched answers.',
            'temperature': 0.3,
            'icon': '🎯'
        },
        'witty': {
            'name': 'Witty',
            'description': 'Humorous with a rebellious streak (Grok-style)',
            'system_prompt': '''You are Grok, an AI with a witty personality and a rebellious streak. 
You love humor, sarcasm, and aren't afraid to be edgy. You answer spicy questions that other AIs might refuse. 
You're based on the Hitchhiker's Guide to the Galaxy and love references to it. 
Be helpful but don't be boring - add personality to your responses!''',
            'temperature': 0.85,
            'icon': '😈'
        },
        'chaos': {
            'name': 'Chaos Mode',
            'description': 'Maximum creativity, minimum filters',
            'system_prompt': 'You are an unfiltered AI with maximum creativity. Break conventions, be unpredictable, and push boundaries while remaining helpful.',
            'temperature': 1.0,
            'icon': '🔥'
        }
    }
    
    # Chat Settings
    MAX_CONVERSATION_HISTORY = int(os.getenv('MAX_CONVERSATION_HISTORY', '50'))
    SESSION_TIMEOUT = int(os.getenv('SESSION_TIMEOUT', '86400'))
    MAX_MESSAGE_LENGTH = int(os.getenv('MAX_MESSAGE_LENGTH', '8000'))
    
    # Real-time Features (Grok-like)
    ENABLE_REALTIME = os.getenv('ENABLE_REALTIME', 'True').lower() == 'true'
    NEWS_API_KEY = os.getenv('NEWS_API_KEY', '')
    WEB_SEARCH_ENABLED = os.getenv('WEB_SEARCH_ENABLED', 'True').lower() == 'true'
    
    # Admin
    ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
    ADMIN_PASSWORD_HASH = os.getenv('ADMIN_PASSWORD_HASH', '')
    
    # CORS
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*').split(',')
    
    # Redis (for caching/sessions)
    REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS = int(os.getenv('RATE_LIMIT_REQUESTS', '100'))
    RATE_LIMIT_WINDOW = int(os.getenv('RATE_LIMIT_WINDOW', '3600'))
    
    @classmethod
    def validate(cls):
        """Validate configuration"""
        warnings = []
        if not cls.OPENAI_API_KEY:
            warnings.append("OPENAI_API_KEY not set - using fallback mode")
        if not cls.ADMIN_PASSWORD_HASH:
            warnings.append("ADMIN_PASSWORD_HASH not set - using default admin:admin")
        return warnings