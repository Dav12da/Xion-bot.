/**
 * GrokChat - Advanced AI Chatbot Frontend
 * Features: Streaming, Multiple Personalities, Modern UI
 */

// ============================================
// Configuration & State
// ============================================

const CONFIG = {
    API_ENDPOINT: localStorage.getItem('apiEndpoint') || 'http://localhost:5000',
    DEFAULT_MODEL: 'gpt-4',
    DEFAULT_PERSONALITY: 'balanced',
    MAX_MESSAGE_LENGTH: 8000
};

const state = {
    currentConversation: null,
    conversations: [],
    isTyping: false,
    currentModel: localStorage.getItem('currentModel') || CONFIG.DEFAULT_MODEL,
    currentPersonality: localStorage.getItem('currentPersonality') || CONFIG.DEFAULT_PERSONALITY,
    user: JSON.parse(localStorage.getItem('user')) || null,
    token: localStorage.getItem('token') || null,
    settings: {
        autoScroll: localStorage.getItem('autoScroll') !== 'false',
        soundEnabled: localStorage.getItem('soundEnabled') === 'true',
        theme: localStorage.getItem('theme') || 'dark'
    },
    personalities: {},
    models: []
};

// ============================================
// DOM Elements
// ============================================

const elements = {
    // Sidebar
    sidebar: document.getElementById('sidebar'),
    menuToggle: document.getElementById('menuToggle'),
    newChatBtn: document.getElementById('newChatBtn'),
    todayChats: document.getElementById('todayChats'),
    weekChats: document.getElementById('weekChats'),
    earlierChats: document.getElementById('earlierChats'),
    
    // User menu
    userBtn: document.getElementById('userBtn'),
    userDropdown: document.getElementById('userDropdown'),
    userName: document.querySelector('.user-name'),
    settingsItem: document.getElementById('settingsItem'),
    themeItem: document.getElementById('themeItem'),
    themeText: document.getElementById('themeText'),
    adminItem: document.getElementById('adminItem'),
    logoutItem: document.getElementById('logoutItem'),
    
    // Navigation
    modelBtn: document.getElementById('modelBtn'),
    modelDropdown: document.getElementById('modelDropdown'),
    currentModel: document.getElementById('currentModel'),
    shareBtn: document.getElementById('shareBtn'),
    clearBtn: document.getElementById('clearBtn'),
    
    // Chat
    welcomeScreen: document.getElementById('welcomeScreen'),
    messagesContainer: document.getElementById('messagesContainer'),
    messagesArea: document.getElementById('messagesArea'),
    
    // Input
    messageInput: document.getElementById('messageInput'),
    sendBtn: document.getElementById('sendBtn'),
    attachBtn: document.getElementById('attachBtn'),
    
    // Modals
    settingsModal: document.getElementById('settingsModal'),
    closeSettings: document.getElementById('closeSettings'),
    saveSettings: document.getElementById('saveSettings'),
    resetSettings: document.getElementById('resetSettings'),
    apiEndpoint: document.getElementById('apiEndpoint'),
    autoScrollToggle: document.getElementById('autoScrollToggle'),
    soundToggle: document.getElementById('soundToggle'),
    
    loginModal: document.getElementById('loginModal'),
    closeLogin: document.getElementById('closeLogin'),
    loginForm: document.getElementById('loginForm'),
    registerForm: document.getElementById('registerForm'),
    guestBtn: document.getElementById('guestBtn'),
    
    // Toast & Loading
    toastContainer: document.getElementById('toastContainer'),
    loadingOverlay: document.getElementById('loadingOverlay'),
    particles: document.getElementById('particles')
};

// ============================================
// Initialization
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

async function initializeApp() {
    // Apply theme
    applyTheme(state.settings.theme);
    
    // Create particle background
    createParticles();
    
    // Setup event listeners
    setupEventListeners();
    
    // Load configuration from API
    await loadConfig();
    
    // Load conversations
    await loadConversations();
    
    // Check auth status
    updateAuthUI();
    
    // Auto-resize textarea
    autoResizeTextarea();
    
    // Create sidebar overlay
    createSidebarOverlay();
    
    // Update model display
    updateModelDisplay();
    
    // Check connection
    checkConnection();
    
    console.log('🤖 GrokChat initialized');
}

function createParticles() {
    const container = elements.particles;
    const particleCount = 25;
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 15 + 's';
        particle.style.animationDuration = (10 + Math.random() * 10) + 's';
        container.appendChild(particle);
    }
}

function createSidebarOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.id = 'sidebarOverlay';
    overlay.addEventListener('click', closeSidebar);
    document.body.appendChild(overlay);
}

// ============================================
// Event Listeners
// ============================================

function setupEventListeners() {
    // Sidebar
    elements.menuToggle.addEventListener('click', toggleSidebar);
    elements.newChatBtn.addEventListener('click', startNewChat);
    
    // User menu
    elements.userBtn.addEventListener('click', toggleUserDropdown);
    elements.settingsItem.addEventListener('click', () => {
        closeUserDropdown();
        openSettings();
    });
    elements.themeItem.addEventListener('click', toggleTheme);
    elements.logoutItem.addEventListener('click', logout);
    
    // Model selector
    elements.modelBtn.addEventListener('click', toggleModelDropdown);
    document.querySelectorAll('.model-option').forEach(btn => {
        btn.addEventListener('click', () => selectModel(btn.dataset.model));
    });
    document.querySelectorAll('.personality-option').forEach(btn => {
        btn.addEventListener('click', () => selectPersonality(btn.dataset.personality));
    });
    
    // Navigation actions
    elements.shareBtn.addEventListener('click', shareChat);
    elements.clearBtn.addEventListener('click', clearCurrentChat);
    
    // Input
    elements.sendBtn.addEventListener('click', sendMessage);
    elements.messageInput.addEventListener('keydown', handleInputKeydown);
    elements.messageInput.addEventListener('input', handleInputChange);
    elements.attachBtn.addEventListener('click', () => showToast('File upload coming soon!', 'info'));
    
    // Feature cards
    document.querySelectorAll('.feature-card').forEach(card => {
        card.addEventListener('click', () => {
            elements.messageInput.value = card.dataset.suggestion;
            handleInputChange();
            sendMessage();
        });
    });
    
    // Personality chips
    document.querySelectorAll('.p-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            selectPersonality(chip.dataset.personality);
            showToast(`Switched to ${chip.textContent.trim()} mode!`, 'success');
        });
    });
    
    // Settings modal
    elements.closeSettings.addEventListener('click', closeSettings);
    elements.saveSettings.addEventListener('click', saveSettings);
    elements.resetSettings.addEventListener('click', resetSettings);
    
    // Login modal
    elements.closeLogin.addEventListener('click', closeLoginModal);
    elements.guestBtn.addEventListener('click', continueAsGuest);
    
    // Login tabs
    document.querySelectorAll('.tab-btn').forEach(tab => {
        tab.addEventListener('click', () => switchLoginTab(tab.dataset.tab));
    });
    
    // Forms
    elements.loginForm.addEventListener('submit', handleLogin);
    elements.registerForm.addEventListener('submit', handleRegister);
    
    // Close dropdowns on outside click
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.model-selector')) {
            closeModelDropdown();
        }
        if (!e.target.closest('.user-menu')) {
            closeUserDropdown();
        }
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeAllModals();
            closeSidebar();
        }
    });
}

// ============================================
// API Functions
// ============================================

async function loadConfig() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/config`);
        const data = await response.json();
        
        if (data.success) {
            state.models = data.data.features.models;
            // Load personalities
            const personalityResponse = await fetch(`${CONFIG.API_ENDPOINT}/api/personalities`);
            const personalityData = await personalityResponse.json();
            
            if (personalityData.success) {
                state.personalities = personalityData.data.personalities;
            }
        }
    } catch (error) {
        console.warn('Could not load config:', error);
    }
}

async function loadConversations() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/conversations`);
        const data = await response.json();
        
        if (data.success) {
            state.conversations = data.data.conversations;
            renderChatHistory();
        }
    } catch (error) {
        console.warn('Could not load conversations:', error);
    }
}

async function sendMessage() {
    const message = elements.messageInput.value.trim();
    if (!message || state.isTyping) return;
    
    // Hide welcome screen, show messages
    elements.welcomeScreen.style.display = 'none';
    elements.messagesContainer.classList.add('active');
    
    // Add user message
    addMessage('user', message);
    
    // Clear input
    elements.messageInput.value = '';
    handleInputChange();
    
    // Show typing indicator
    showTypingIndicator();
    
    // Disable input
    state.isTyping = true;
    elements.sendBtn.disabled = true;
    
    try {
        // Use streaming API
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/chat/stream`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                conversation_id: state.currentConversation,
                model: state.currentModel,
                personality: state.currentPersonality
            })
        });
        
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullResponse = '';
        let messageElement = null;
        
        // Remove typing indicator
        removeTypingIndicator();
        
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));
                        
                        if (data.chunk) {
                            fullResponse += data.chunk;
                            
                            if (!messageElement) {
                                messageElement = addMessage('assistant', fullResponse, true);
                            } else {
                                updateMessage(messageElement, fullResponse);
                            }
                        }
                        
                        if (data.done) {
                            state.currentConversation = data.conversation_id;
                            await loadConversations();
                        }
                    } catch (e) {
                        // Ignore parse errors
                    }
                }
            }
        }
        
        if (state.settings.soundEnabled) {
            playMessageSound();
        }
        
    } catch (error) {
        removeTypingIndicator();
        addMessage('assistant', 'Sorry, I encountered an error. Please check your connection and try again.');
        showToast('Failed to send message', 'error');
        console.error('Chat error:', error);
    } finally {
        state.isTyping = false;
        elements.sendBtn.disabled = elements.messageInput.value.length === 0;
    }
}

async function checkConnection() {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/health`);
        const data = await response.json();
        
        if (data.status === 'healthy') {
            console.log(`✅ Connected to GrokChat API (AI: ${data.ai_enabled ? 'Enabled' : 'Fallback'})`);
        }
    } catch (error) {
        console.warn('⚠️ API connection failed');
    }
}

// ============================================
// UI Functions
// ============================================

function addMessage(role, content, isStreaming = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = role === 'user' ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
    
    const contentWrapper = document.createElement('div');
    contentWrapper.className = 'message-content';
    
    const header = document.createElement('div');
    header.className = 'message-header';
    
    const author = document.createElement('span');
    author.className = 'message-author';
    author.textContent = role === 'user' ? 'You' : 'GrokChat';
    
    if (role === 'assistant') {
        const model = document.createElement('span');
        model.className = 'message-model';
        model.textContent = state.personalities[state.currentPersonality]?.name || 'AI';
        header.appendChild(author);
        header.appendChild(model);
    } else {
        header.appendChild(author);
    }
    
    const text = document.createElement('div');
    text.className = 'message-text';
    text.innerHTML = formatMessage(content);
    
    contentWrapper.appendChild(header);
    contentWrapper.appendChild(text);
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentWrapper);
    
    elements.messagesArea.appendChild(messageDiv);
    
    if (state.settings.autoScroll) {
        scrollToBottom();
    }
    
    // Highlight code blocks
    messageDiv.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
    });
    
    return messageDiv;
}

function updateMessage(messageElement, content) {
    const textElement = messageElement.querySelector('.message-text');
    textElement.innerHTML = formatMessage(content);
    
    // Highlight code blocks
    messageElement.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
    });
    
    if (state.settings.autoScroll) {
        scrollToBottom();
    }
}

function formatMessage(content) {
    // Use marked for markdown parsing
    if (typeof marked !== 'undefined') {
        marked.setOptions({
            highlight: function(code, lang) {
                if (lang && hljs.getLanguage(lang)) {
                    return hljs.highlight(code, { language: lang }).value;
                }
                return hljs.highlightAuto(code).value;
            }
        });
        return marked.parse(content);
    }
    
    // Fallback formatting
    return content
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br>');
}

function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message assistant typing';
    typingDiv.id = 'typingIndicator';
    
    typingDiv.innerHTML = `
        <div class="message-avatar"><i class="fas fa-robot"></i></div>
        <div class="message-content">
            <div class="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    
    elements.messagesArea.appendChild(typingDiv);
    scrollToBottom();
}

function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) indicator.remove();
}

function scrollToBottom() {
    elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight;
}

function renderChatHistory() {
    const today = new Date().toDateString();
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    
    elements.todayChats.innerHTML = '';
    elements.weekChats.innerHTML = '';
    elements.earlierChats.innerHTML = '';
    
    state.conversations.forEach(conv => {
        const item = createChatItem(conv);
        const convDate = new Date(conv.updated_at);
        
        if (convDate.toDateString() === today) {
            elements.todayChats.appendChild(item);
        } else if (convDate > weekAgo) {
            elements.weekChats.appendChild(item);
        } else {
            elements.earlierChats.appendChild(item);
        }
    });
}

function createChatItem(conv) {
    const li = document.createElement('li');
    li.className = 'chat-item';
    li.dataset.id = conv.id;
    if (conv.id === state.currentConversation) {
        li.classList.add('active');
    }
    
    li.innerHTML = `
        <i class="fas fa-comment"></i>
        <span>${conv.title}</span>
        <div class="chat-actions">
            <button class="delete-chat" title="Delete">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    li.addEventListener('click', (e) => {
        if (!e.target.closest('.chat-actions')) {
            loadConversation(conv.id);
        }
    });
    
    li.querySelector('.delete-chat').addEventListener('click', (e) => {
        e.stopPropagation();
        deleteConversation(conv.id);
    });
    
    return li;
}

async function loadConversation(id) {
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/conversations/${id}`);
        const data = await response.json();
        
        if (data.success) {
            state.currentConversation = id;
            
            // Clear and load messages
            elements.messagesArea.innerHTML = '';
            elements.welcomeScreen.style.display = 'none';
            elements.messagesContainer.classList.add('active');
            
            data.data.conversation.messages.forEach(msg => {
                addMessage(msg.role, msg.content);
            });
            
            // Update active state
            document.querySelectorAll('.chat-item').forEach(item => {
                item.classList.toggle('active', item.dataset.id === id);
            });
            
            closeSidebar();
        }
    } catch (error) {
        showToast('Failed to load conversation', 'error');
    }
}

async function deleteConversation(id) {
    if (!confirm('Delete this conversation?')) return;
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/conversations/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            if (state.currentConversation === id) {
                startNewChat();
            }
            await loadConversations();
            showToast('Conversation deleted', 'success');
        }
    } catch (error) {
        showToast('Failed to delete conversation', 'error');
    }
}

function startNewChat() {
    state.currentConversation = null;
    elements.messagesArea.innerHTML = '';
    elements.welcomeScreen.style.display = 'flex';
    elements.messagesContainer.classList.remove('active');
    
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.remove('active');
    });
    
    closeSidebar();
    elements.messageInput.focus();
}

async function clearCurrentChat() {
    if (!state.currentConversation) return;
    
    if (!confirm('Clear all messages in this conversation?')) return;
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/conversations/${state.currentConversation}/clear`, {
            method: 'POST'
        });
        
        if (response.ok) {
            elements.messagesArea.innerHTML = '';
            showToast('Conversation cleared', 'success');
        }
    } catch (error) {
        showToast('Failed to clear conversation', 'error');
    }
}

function shareChat() {
    if (!state.currentConversation) {
        showToast('Start a conversation first!', 'info');
        return;
    }
    
    const url = `${window.location.origin}?conversation=${state.currentConversation}`;
    navigator.clipboard.writeText(url);
    showToast('Link copied to clipboard!', 'success');
}

// ============================================
// Model & Personality Selection
// ============================================

function selectModel(model) {
    state.currentModel = model;
    localStorage.setItem('currentModel', model);
    
    document.querySelectorAll('.model-option').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.model === model);
    });
    
    updateModelDisplay();
    closeModelDropdown();
    showToast(`Switched to ${model}`, 'success');
}

function selectPersonality(personality) {
    state.currentPersonality = personality;
    localStorage.setItem('currentPersonality', personality);
    
    document.querySelectorAll('.personality-option').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.personality === personality);
    });
    
    updateModelDisplay();
    closeModelDropdown();
}

function updateModelDisplay() {
    const personality = state.personalities[state.currentPersonality];
    const icon = personality?.icon || '⚡';
    const name = personality?.name || 'GrokChat';
    
    elements.currentModel.textContent = name;
    elements.modelBtn.querySelector('.model-icon').textContent = icon;
}

function toggleModelDropdown() {
    elements.modelDropdown.classList.toggle('active');
}

function closeModelDropdown() {
    elements.modelDropdown.classList.remove('active');
}

// ============================================
// Sidebar Functions
// ============================================

function toggleSidebar() {
    elements.sidebar.classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
}

function closeSidebar() {
    elements.sidebar.classList.remove('open');
    const overlay = document.getElementById('sidebarOverlay');
    if (overlay) overlay.classList.remove('active');
}

// ============================================
// User Menu
// ============================================

function toggleUserDropdown() {
    elements.userDropdown.classList.toggle('active');
}

function closeUserDropdown() {
    elements.userDropdown.classList.remove('active');
}

function updateAuthUI() {
    if (state.user) {
        elements.userName.textContent = state.user.username;
        elements.adminItem.style.display = state.user.is_admin ? 'flex' : 'none';
    } else {
        elements.userName.textContent = 'Guest';
        elements.adminItem.style.display = 'none';
    }
}

// ============================================
// Authentication
// ============================================

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            state.token = data.data.access_token;
            state.user = data.data.user;
            localStorage.setItem('token', state.token);
            localStorage.setItem('user', JSON.stringify(state.user));
            
            updateAuthUI();
            closeLoginModal();
            showToast(`Welcome back, ${state.user.username}!`, 'success');
        } else {
            showToast(data.error || 'Login failed', 'error');
        }
    } catch (error) {
        showToast('Login failed', 'error');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    
    try {
        const response = await fetch(`${CONFIG.API_ENDPOINT}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Account created! Please login.', 'success');
            switchLoginTab('login');
        } else {
            showToast(data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        showToast('Registration failed', 'error');
    }
}

function logout() {
    state.token = null;
    state.user = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    
    updateAuthUI();
    closeUserDropdown();
    showToast('Logged out', 'info');
}

function continueAsGuest() {
    closeLoginModal();
    showToast('Continuing as guest', 'info');
}

function switchLoginTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tab);
    });
    
    if (tab === 'login') {
        elements.loginForm.classList.remove('hidden');
        elements.registerForm.classList.add('hidden');
    } else {
        elements.loginForm.classList.add('hidden');
        elements.registerForm.classList.remove('hidden');
    }
}

// ============================================
// Settings
// ============================================

function openSettings() {
    elements.apiEndpoint.value = CONFIG.API_ENDPOINT;
    elements.autoScrollToggle.checked = state.settings.autoScroll;
    elements.soundToggle.checked = state.settings.soundEnabled;
    
    // Update theme buttons
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.theme === state.settings.theme);
    });
    
    elements.settingsModal.classList.add('active');
}

function closeSettings() {
    elements.settingsModal.classList.remove('active');
}

function saveSettings() {
    CONFIG.API_ENDPOINT = elements.apiEndpoint.value.trim() || 'http://localhost:5000';
    state.settings.autoScroll = elements.autoScrollToggle.checked;
    state.settings.soundEnabled = elements.soundToggle.checked;
    
    // Get selected theme
    const activeTheme = document.querySelector('.theme-btn.active');
    if (activeTheme) {
        state.settings.theme = activeTheme.dataset.theme;
        applyTheme(state.settings.theme);
    }
    
    // Save to localStorage
    localStorage.setItem('apiEndpoint', CONFIG.API_ENDPOINT);
    localStorage.setItem('autoScroll', state.settings.autoScroll);
    localStorage.setItem('soundEnabled', state.settings.soundEnabled);
    localStorage.setItem('theme', state.settings.theme);
    
    checkConnection();
    closeSettings();
    showToast('Settings saved', 'success');
}

function resetSettings() {
    elements.apiEndpoint.value = 'http://localhost:5000';
    elements.autoScrollToggle.checked = true;
    elements.soundToggle.checked = false;
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.theme === 'dark');
    });
}

function applyTheme(theme) {
    if (theme === 'system') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    } else {
        document.documentElement.setAttribute('data-theme', theme);
    }
    
    elements.themeText.textContent = theme === 'dark' ? 'Dark mode' : 'Light mode';
}

function toggleTheme() {
    const newTheme = state.settings.theme === 'dark' ? 'light' : 'dark';
    state.settings.theme = newTheme;
    applyTheme(newTheme);
    localStorage.setItem('theme', newTheme);
}

// ============================================
// Input Handling
// ============================================

function handleInputKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}

function handleInputChange() {
    const length = elements.messageInput.value.length;
    elements.sendBtn.disabled = length === 0 || state.isTyping;
}

function autoResizeTextarea() {
    const textarea = elements.messageInput;
    textarea.addEventListener('input', () => {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    });
}

// ============================================
// Modals
// ============================================

function openLoginModal() {
    elements.loginModal.classList.add('active');
}

function closeLoginModal() {
    elements.loginModal.classList.remove('active');
}

function closeAllModals() {
    closeSettings();
    closeLoginModal();
    closeModelDropdown();
}

// ============================================
// Toast Notifications
// ============================================

function showToast(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    
    toast.innerHTML = `
        <i class="fas fa-${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ============================================
// Sound Effects
// ============================================

function playMessageSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 600;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
    } catch (e) {
        // Audio not supported
    }
}

// ============================================
// Window Events
// ============================================

window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        closeSidebar();
    }
});

// Handle URL params (shared conversations)
window.addEventListener('load', () => {
    const params = new URLSearchParams(window.location.search);
    const conversationId = params.get('conversation');
    if (conversationId) {
        loadConversation(conversationId);
    }
});

// Export for debugging
window.grokChat = {
    state,
    CONFIG,
    elements,
    sendMessage,
    startNewChat,
    loadConversation
};